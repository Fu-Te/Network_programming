# happyhackingtools
ペネトレーションツールを目指して作っているものです．

Python3.9.7で動作確認済

必要なパッケージのインストール
```
$ pip install -r requirements.txt
```

サーバー作動
```
$ python3 app.py
```

[http://127.0.0.1:8000](http://127.0.0.1:8000)にアクセスして利用可能．